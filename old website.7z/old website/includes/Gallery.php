<script>
    $("form").submit(function(e){ //when form submit, trigger this function
        e.preventDefault(); //prevent form from submitting
        var formData = new FormData($(this)[0]);//grab what would've been submitted
        formData.append("Submit",true); //"fake" pressing submit button
        $.ajax({url: "includes/Gallery.php", 
            type: "POST",
            data: formData,
            success: function(result){$("#dynamicContent").html(result);},//place output in the dynamic content div
			error: function(result){$("#dynamicContent").html("Error!");},
            cache: false,
            contentType: false,
            processData: false,
            enctype: 'multipart/form-data'
        });
    });
</script>


<?php

function uploadFile($fileName, $file_ext){ //function that actually transfers the images into the target directoy and makes a thumbnail for the webpage to show
    $target_path = "../images";
    $thumb_path = "../images/thumbs";

    //Set thumbnail size
    $thumb_width = 200;
    $thumb_height = 160;

    if (move_uploaded_file($_FILES['pictureFile']['tmp_name'], $target_path."/". $_FILES['pictureFile']['name']) === FALSE)
        echo "Could not move uploaded file to ".$target_path." ".htmlentities($_FILES['pictureFile']['name'])."<br/>\n";
    else{
        //thumbnail creation
        
        $upload_image = $target_path."/". basename($fileName);  
        $thumbnail = $thumb_path."/".$fileName;
        list($width,$height) = getimagesize($upload_image);
        $thumb_create = imagecreatetruecolor($thumb_width,$thumb_height);
        switch($file_ext){
            case 'jpg':
            case 'jpeg':
                $source = imagecreatefromjpeg($upload_image);
                break;
            case 'png':
                $source = imagecreatefrompng($upload_image);
                break;
            case 'gif':
                $source = imagecreatefromgif($upload_image);
                break;
            default:
                $source = imagecreatefromjpeg($upload_image);
                break;
        }
        imagecopyresized($thumb_create,$source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);
        switch($file_ext){
            case 'jpg' || 'jpeg':
                imagejpeg($thumb_create,$thumbnail,100);
                break;
            case 'png':
                imagepng($thumb_create,$thumbnail,100);
                break;
            case 'gif':
                imagegif($thumb_create,$thumbnail,100);
                break;
            default:
                imagejpeg($thumb_create,$thumbnail,100);
        }
        echo "Successfully uploaded ".$target_path." ".htmlentities($_FILES['pictureFile']['name'])."<br/>\n";
    }
}


if(isset($_POST['Submit'])){
    $errors = array();
    if ($_FILES['pictureFile']){ //verifies the user has submitted a picture file
        $fileExt = array('jpeg', 'jpg', 'png', 'gif'); //acceptable file extentions
        $fileName = $_FILES['pictureFile']['name']; //captures the name of the file
        $file_ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION)); //captures the file extention
        if(!in_array($file_ext, $fileExt)){ //verifies the file is in the file extention array
            $errors[] = "Invalid File Type! Please upload a .jpeg, .jpg, .png or .gif!";
        }
        if(count($errors) == 0){ //if it passes all error handling..
            uploadFile($fileName, $file_ext);
        }
        else{
            foreach($errors as $error){ //prints out errors if the user did something wrong
                echo "$error<br>";
            }
        }
    }
}
?>
<form method="post" enctype="multipart/form-data" action="">
    <input type="file" name="pictureFile"/>
    <input type="submit" name="Submit" value="Upload"/>
</form>
<div id="output"></div>

<?php // Let's gather all images to display in the appropriate box
	$directory = '../images/thumbs'; // Where all the images are located
	$images = array_values(array_diff(scandir($directory), array('..','.'))); // Don't include parent directories
	foreach ($images as $image){ ?>
		<a href="../images/<?php echo $image; ?>" target="_blank"><img src="../images/thumbs/<?php echo $image; ?>"/></a>
    <?php } ?>