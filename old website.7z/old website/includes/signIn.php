<script>
	function ajaxSubmit(){
		var formData = {
            'username' : $('input[name=username]').val(),
            'pass' : $('input[name=pass]').val(),
            'submit' : true
            };

		$.ajax({
			url: "includes/signIn.php",
			type: "POST",
			data: formData,
			success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");}
		});
		return false;
	};
</script>
<?php
@session_start();
require('dbconnect.php');
$username = $_POST['username'] ?? "";

function usernameValid($username, $errors){
    $validUser = '/^[\w]{6,12}$/';
    if (!preg_match($validUser, $username)){
        $errors[] = "Username must be between 6-12 characters in length and can only contain alphanumeric characters(A-Z, a-z, 0-9 or _).";
    }
    
    return $errors;
}

if(isset($_POST['submit'])){
    date_default_timezone_set('America/New_York');
    $dt = new DateTime();
    $password = $_POST['pass'];
    $errors = array();
    $errors = usernameValid($username, $errors);
    if(count($errors) == 0){
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
        $stmt->execute([$username]);
        $query = $stmt->fetchAll();

        if(count($query)==0){die('<script>alert("Wrong username or password!");</script>');}
        if(password_verify($password, $query[0]['password'])){
            $_SESSION['username'] = $query[0]['username'];
            $_SESSION['accessLevel'] = $query[0]['accessLevel'];
            $stmt = $pdo->prepare('INSERT INTO login_log(username, logDate) VALUES (?,?)');
            $stmt->execute([$username, $dt->format('Y-m-d H:i:s')]);
            echo '<script>alert("Successfully logged in!");</script>';
            $_SESSION['username'] = $username;
            echo '<script>location="index.php";</script>';
        }
        else{
            echo '<script>alert("Wrong username or password!");</script>';
        }
    }
    else{
        foreach($errors as $error){
            echo $error."<br/>";
        }
    }
}
else{
    ?>
    Username:<input type="text" name="username" value="<?php echo $username;?>" required><br/>
    Password:<input type="password" name="pass" value="" required><br/>
    <button name="submit" onclick="ajaxSubmit();">Submit</button>
    <a href="" onclick="ajaxNavigation('signUp'); return false;">Sign Up</a>
    <a href="" onclick="ajaxNavigation('PasswordReset'); return false;">Forgot Password</a>
    <div id="output"></div>
    <?php
}
?>