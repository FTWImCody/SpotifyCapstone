<script>
	function ajaxConvert(){ //Grabs number from the input text named number and passes in a fake submit button for isset($_POST['submit]), sends all info to "includes/converter.php"
		var formData = {
            'number' : $('input[name=number]').val(),
            'submit' : true
            };

		$.ajax({
			url: "includes/converter.php",
			type: "POST",
			data: formData,
			success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");}
		});
		return false;
	};
</script>
<?php
    $num = $_POST['number'] ?? ""; //sets $num to "" if $_POST['number'] has nothing in it
    if (isset($_POST['submit'])){ //only executes if 'submit' isset
        $errors = array();
        if(empty($num)){ //checks to see if the user entered anything
            $errors[] = "You did not enter anything!";

        }
        if (!is_numeric($num)){ //verifies to make sure the user input a number
            $errors[] = "Input not a number!";
        }
        if(($num >= 0) == false){ //verifies the number entered is positive
            $errors[] = "Input is not a positive number!";
        }
        if(count($errors) == 0){ //if it passes all the error checking, it will echo out all the conversions
            echo "Your number is $num.<br>";
            echo "Decimal: $num.<br>";
            echo "Binary: " . decbin($num) . ".<br>";
            echo "Octal: " . decoct($num) . ".<br>";
            echo "Hexadecimal: " . dechex($num) . ".<br>";
        }
        else{ //if it fails error checking, will echo out all the errors
            foreach($errors as $x){
                echo "$x<br>";
            }
        }
    }
    else{
        ?>
        Enter a positive number:
        <input type="text" name="number" value="<?php echo $num; ?>"><br>
        <button name="submit" onClick="ajaxConvert();">Submit</button>
        <div id="output"></div>
        <?php
    }
?>