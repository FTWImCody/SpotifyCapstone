
<script>
    $("form").submit(function(e){ //when form submit, trigger this function
        e.preventDefault(); //prevent form from submitting
        var formData = new FormData($(this)[0]);//grab what would've been submitted
        formData.append("Header",$('input[name=Header]').is(':checked') ? "true" : "");
        formData.append("Submit",true); //"fake" pressing submit button
        $.ajax({url: "includes/CSV.php", 
            type: "POST",
            data: formData,
            success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");},
            cache: false,
            contentType: false,
            processData: false,
            enctype: 'multipart/form-data'
        });
    });
</script>

<head>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
</body>

<?php
if(isset($_POST['Submit'])){
    if(isset($_FILES['new_file'])){ //only executes if a user selected a file
        @$fp = file($_FILES['new_file']['tmp_name']) or die("Can not open uploaded file. "); //sets the file to a variable $fp
        $file_ext = pathinfo($_FILES['new_file']['name'], PATHINFO_EXTENSION);
        if($file_ext == "csv" || $file_ext == "log"){ //error checking to make sure the file submitted is .csv or .log
            echo "<table>";
            if($_POST['Header']){ //if user selected the checkbox for headers then..
                echo "<thead>";
                $header = explode(",", $fp[0]); //exlpodes off first line for header
                echo "<tr>";
                foreach($header as $line){
                    echo "<th>".$line."</th>"; //prints the header
                }
                echo "</tr></thead>";
            }
            else{
                echo "<tbody>";
                $header = explode(",", $fp[0]); //explodes the first line
                echo "<tr>";
                foreach($header as $line){
                    echo "<td>".$line."</td>"; //prints it as header in a regular row tag so it is not bolded
                }
                echo "</tr>";
            }
            $fp = array_slice($fp, 1); //removes first line
            foreach($fp as $line){ //prints off all lines/rows into a table
                echo "<tr>";
                $explodeLine = explode(",", $line);
                foreach($explodeLine as $data){
                    echo "<td>".$data."</td>";
                }
                echo "</tr>";
            }      
            echo "</table>";
        }
        else{
            echo "Please submit a valid file!";
        }
    }
}
else{
    ?>
<form method="post" enctype="multipart/form-data" action="">
    Upload file:<br/>
    <input type="file" name="new_file" value=""/>
    <input type="submit" name="Submit" value="Upload File"/><br/>
    <input type="checkbox" name="Header" value="True"/>
    Check this box if your CSV has headers!
</form>
<div id="output"></div>
<?php
}
?>