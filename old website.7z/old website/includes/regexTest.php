<script>
	function ajaxRegex(){  //ajax function that passes needle, haystack, case values and submit
		var formData = {
            'needle' : $('input[name=needle]').val(),
			'haystack' : $('input[name=haystack]').val(),
			'case' : $('input[name=case]').is(':checked') ? 'i':'',
            'submit' : true
            };

		$.ajax({
			url: "includes/regexTest.php",
			type: "POST",
			data: formData,
			success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");}
		});
		return false;
	};
</script>


<?php
$needle = $_POST['needle'] ?? ""; //if needle is not set then it will be empty
$haystack = $_POST['haystack'] ?? ""; //if haystack is not set then it will be empty
$case = $_POST['case'] ?? ""; //if case is not set it will be empty

if(isset($_POST['submit'])){
	if($needle != "" && $haystack != ""){ //as long as something is in each field it will execute the matching process
		if(preg_match("/".$needle."/".$case, $haystack))
			echo "Matched!";
		else
			echo "No Match.";
	}
}
else{
	?>
	Needle:<input type="text" name="needle" value="<?php echo $needle;?>"><br/>
	Haystack:<input type="text" name="haystack" value="<?php echo $haystack;?>"><br/>
	Case Insensitive:<input type="checkbox" name="case" value="i" <?php
	if($case == "i")
    echo 'checked="checked"'?>><br/>
	<button name="submit" onclick="ajaxRegex();">Submit</button> <!--on click will launch the ajax function for submitting the infomation-->
	<div id="output"></div>
<?php
}
?>