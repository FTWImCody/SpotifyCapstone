<?php //switch statement that will open each webpage from the Ajax function in Index.php
    $page = $_REQUEST['page'] ?? "null";
	switch($page){
		case 'Home':
			echo "Webwerx Drafts";
			break;
		case 'Gallery':
			include 'Gallery.php';
		break;
		case 'DieRoller':
			include 'DieRoller.php';
			break;
		case 'Converter':
			include 'converter.php';
			break;
		case 'csvViewer':
			include 'CSV.php';
			break;
		case 'Regex':
			include 'regexTest.php';
			break;
		case 'signUp':
			include 'signUp.php';
			break;
		case 'signIn':
			include 'signIn.php';
			break;
		case 'PasswordReset':
			include 'Forgot.php';
			break;
		case 'SecurityQ':
			include 'SecurityQ.php';
			break;
		case 'Quizzer':
			include 'quizzer.php';
			break;
		case 'Quiz List':
			include 'quizList.php';
			break;
		case 'Clients':
			include 'clients.php';
			break;
		case 'Logout':
			@session_start();
			@session_destroy();
			echo '<script>alert("Successfully logged out!");</script>';
			echo '<script>window.location.replace("index.php");</script>';
			break;
		default:
			echo "Webpage doesn't exist!";
	};
	?>