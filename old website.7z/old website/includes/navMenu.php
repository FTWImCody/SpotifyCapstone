<?php
$_SESSION['username'] = $_SESSION['username'] ?? 'Guest'; //sets username = to Guest if no session username has been set
$_SESSION['accessLevel'] = $_SESSION['accessLevel'] ?? 0;
?>
<div class="navbar">
<a href="" onclick="ajaxNavigation('Home'); return false;">Home</a>
<?php
if($_SESSION['accessLevel'] == 4){
  ?>
  <a href="" onclick="ajaxNavigation('Clients'); return false;">Client List</a>
  <?php
}
?>
<a href="" onclick="ajaxNavigation('Gallery'); return false;">Gallery</a>
<a href="" onclick="ajaxNavigation('csvViewer'); return false;">CSV Viewer</a>
<a href="" onclick="ajaxNavigation('Quiz List'); return false;">Flash Card</a>
<div class="dropdown">
  <button class="dropbtn">Misc Tools 
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-content">
    <a href="" onclick="ajaxNavigation('DieRoller'); return false;">DieRoller</a>
    <a href="" onclick="ajaxNavigation('Converter'); return false;">Number Converter</button>
    <a href="" onclick="ajaxNavigation('Regex'); return false;">Regex Tester</a>
  </div>
</div>
<?php
if($_SESSION['username'] != 'Guest'){ //Will return a logout button if the user has actually logged into an account
  echo "<a style=\"float:right\"href=\"\" onclick=\"ajaxNavigation('Logout'); return false;\">Logout</a>";
}
?>
<a style="float:right" href="" onclick="ajaxNavigation('signIn'); return false;"><?php echo $_SESSION['username'] ?? 'Guest';?></a> <!-- Sets the SignIn navigation to user if no one is logged in or the username if some one is logged in -->
</div>