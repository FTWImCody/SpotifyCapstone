<?php
session_start();
?>

<script>
    $("csvUpload").submit(function(e){ //when form submit, trigger this function
        e.preventDefault(); //prevent form from submitting
        var formData = new FormData($(this)[0]);//grab what would've been submitted
        formData.append("Submit",true); //"fake" pressing submit button
        $.ajax({url: "includes/quizList.php", 
            type: "POST",
            data: formData,
            success: function(result){$("#dynamicContent").html(result);},
			error: function(result){$("#dynamicContent").html("Error!");},
            cache: false,
            contentType: false,
            processData: false,
            enctype: 'multipart/form-data'
        });
    });
</script>
<?php

function uploadFile($fileName, $file_ext){ //same upload file from Gallery
    $target_path = "../quizzes";


    if (move_uploaded_file($_FILES['quiz']['tmp_name'], $target_path."/". $_FILES['quiz']['name']) === FALSE)
        echo "Could not move uploaded file to ".$target_path." ".htmlentities($_FILES['quiz']['name'])."<br/>\n";
    else{ 
        $upload_csv = $target_path."/". basename($fileName);  
        echo "Successfully uploaded ".$target_path." ".htmlentities($_FILES['quiz']['name'])."<br/>\n";
    }
}

if(isset($_POST['Submit'])){ //if submit on form, it will check to make sure it is a .csv, if not will return errors..if so then will upload file..
    $errors = array();
    if ($_FILES['quiz']){
        $fileExt = array('csv');
        $fileName = $_FILES['quiz']['name'];
        $file_ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if(!in_array($file_ext, $fileExt)){
            $errors[] = "Invalid File Type! Please upload a .csv!";
        }
        if(count($errors) == 0){
            uploadFile($fileName, $file_ext);
        }
        else{
            foreach($errors as $error){
                echo "$error<br>";
            }
        }
    }
}
?>
<form method="post" enctype="multipart/form-data" action="" id="csvUpload">
    <input type="file" name="quiz"/>
    <input type="submit" name="Submit" value="Upload"/>
</form>
<div id="output"></div>

<?php // Let's gather all csvs to display in the appropriate box
	$directory = '../quizzes'; // Where all the csvs are located
	$csvs = array_values(array_diff(scandir($directory), array('..','.'))); // Don't include parent directories
	foreach ($csvs as $csv){ ?>
        <form method="post" enctype="multipart/form-data" action="includes/quizzer.php" target="_blank">
            <input type="submit" name="submit" value="<?php echo $csv; ?>"/><br/>
        </form> <!-- onsubmit should capture the csv name to open on the quizzer.php -->
    <?php 
} ?>