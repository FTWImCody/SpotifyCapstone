<script>
	function ajaxRoller(){ //captures the fields from the input types 'times' and 'sides' as well as a fake submit button for isset($_POST['submit])
		var formData = {
            'times' : $('input[name=times]').val(),
            'sides' : $('input[name=sides]').val(),
            'submit' : true
        };

		$.ajax({
			url: "includes/DieRoller.php", //passes all values unto "includes/DieRoller.php"
			type: "POST",
			data: formData,
			success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");}
		});
		return false;
	};
</script>

<?php
    function DieRoller($times, $sides) //returns total number of rolled dice
    {
        $total = 0;
        for($i = 0; $i < $times; $i++)
        {
            $total += mt_rand(1, $sides);
        }
    return $total;
    }
    $times = $_POST['times'] ?? 1;
    $sides = $_POST['sides'] ?? 6;

    if (isset($_POST['submit'])){
        $errors = array();
        if(Empty($times)){ //verifies user entered something in $times input
            $errors[] = "You did not enter a times!";
        }
        if (!is_numeric($times)){ //verifies the user entered a number for $times
            $errors[] = "Times not a number!";
        }
        if(($times >= 0) == false){ //verifies user entered a positive number for $times
            $errors[] = "Times is not a positive number!";
        }
        if(Empty($sides)){ //verifies user entered something in the $sides input
            $errors[] = "You did not enter a sides!";
        }
        if (!is_numeric($sides)){ //verifies the user entered a number for $sides
            $errors[] = "Sides not a number!";
        }
        if(($sides >= 0) == false){ //verifies user entered a positive number for $sides
            $errors[] = "Sides is not a positive number!";
        }
        if(count($errors) == 0){ //if there are no errors, outputs the dice roll total
            echo 'You rolled a ' . DieRoller($times, $sides) . '.';
        }
        else{
            foreach($errors as $error){ //if it does not pass all the error handling, prints out all the errors for the user
            echo "$error<br/>";
            }
        }
    }
    else{
        ?>
        Number of times: <input type="text" name="times" value="<?php echo $times; ?>"><br/>
        Number of sides: <input type="text" name="sides" value="<?php echo $sides; ?>"><br/>
        <button name="submit" onclick="ajaxRoller()">Roll!</button><br/>
        <div id="output"></div>
        <?php
    }
?>