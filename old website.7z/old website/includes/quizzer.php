<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> <!--importing JQquery because we are not using index.php for this file-->
<script>
	function ajaxQuestion(questionNum){//passes questionNum and Submit after Start Quiz is clicked
		var formData = {
            'questionNum' : questionNum,
            'Submit' : true
            };

		$.ajax({
			url: "quizzer.php",
			type: "POST",
			data: formData,
			success: function(result){$("#quiz").html(result);},
			error: function(ts){alert(ts.responseText);}
		});
		return false;
	};

    function ajaxFlip(questionNum){ //passes questionNum and Submit1 when Answer button is clicked
		var formData = {
            'questionNum' : questionNum,
            'Submit1' : true
            };

		$.ajax({
			url: "quizzer.php",
			type: "POST",
			data: formData,
			success: function(result){$("#card").html(result);},
			error: function(result){$("#card").html("Error!");}
		});
		return false;
	};

    function ajaxEnd(){  //passes End when End Quiz is clicked..
		var formData = {
            'End' : true
            };

		$.ajax({
			url: "quizzer.php",
			type: "POST",
			data: formData,
			success: function(result){$("#card").html(result);},
			error: function(result){$("#card").html("Error!");}
		});
		return false;
	};

</script>

<?php
    @session_start(); //starts session if it has not already been started

    $target_path = "../quizzes"; //target directory for all the uploaded quizzes
    if(isset($_POST['submit'])){
        $fp = file($target_path."/".$_POST['submit']) or die("Cannot open file!");
        $_SESSION['quiz'] = array();
        $_SESSION['quiz']['name'] = $_POST['submit'];
        $_SESSION['quiz']['data'] = $fp; //sets up the quiz file into a session variable to be used throughout the quizzer
    }

    if(isset($_POST['Submit'])){
        $num = $_POST['questionNum'] ?? 0; //num is equal to 0 if questionNum is not set
        $questionNum = explode(",", $_SESSION['quiz']['data'][$num]); //splits the csv on "," to give us the question and answer separated
        $question = $questionNum[0];
        

        if ($num < count($_SESSION['quiz']['data'])-1){ //if not on last question..
            echo "<div id='card'>$question</div><br/>"; //echos out the question
            ?>
            <button name="flip" onclick="ajaxFlip(<?php echo $num ?>)">Answer</button> <!-- if Answer is clicked it will send the questionNum to ajaxFlip -->
            <?php

            if($num == 0){
                ?>
                <button name="prev" onclick="">&nbsp;&nbsp;</button> <!--If on the first question, it will show an empty button-->
                <?php
            }
            
            else{
                ?>
                <button name="prev" onclick="ajaxQuestion(<?php echo $num - 1; ?>)">Previous Question</button> <!--If not on the first question it will show a previous question button when clicked will show the previous question-->
                <?php
            }
            ?>
            <button name="next" onclick="ajaxQuestion(<?php echo $num + 1; ?>)">Next Question</button> <!--next question button as long as it is not the last question-->
            <?php
        }
        else{
            echo "<div id='card'>$question</div><br/>";
            ?>
            <button name="flip" onclick="ajaxFlip(<?php echo $num ?>)">Answer</button>
            <button name="prev" onclick="ajaxQuestion(<?php echo $num - 1; ?>)">Previous Question</button>
            <button name="end" onclick="ajaxEnd()">End Quiz!</button> <!--gives an end quiz button instead of next question button if on last question-->
            <?php
        }

    }
    else if(isset($_POST['Submit1'])){ //if answer button is clicked, then it will display answer in the card div instead of question
        $num = $_POST['questionNum'] ?? 0;
        $questionNum = explode(",", $_SESSION['quiz']['data'][$num]);
        $answer = $questionNum[1];
        echo $answer;
    }
    else{
        ?>
        <div id="quiz">
            <button name="start" onclick="ajaxQuestion(0);">Start Quiz</button><!--Displays the Start Quiz Button if the tab has just been opened-->
        </div>
        <?php
    }

    if(isset($_POST['End'])){ //Upon ending it will clear the session quiz variable and close the tab
        $_SESSION['quiz'] = array();
        echo "<script>window.close();</script>";
    }
?>