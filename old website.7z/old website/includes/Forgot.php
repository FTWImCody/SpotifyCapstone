<?php
session_start();
function randomPassword() { //function that creates a random password using all alphanumeric characters
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
?>

<script>
	function ajaxSubmit(){ //when user submits the username
		var formData = {
            'username' : $('input[name=username]').val(),
            'submit' : true
            };

		$.ajax({
			url: "includes/Forgot.php",
			type: "POST",
			data: formData,
			success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");}
		});
		return false;
	};
	</script>
<script>
	function ajaxSubmit2(){ //when user submits the answer to the forgotten password
		var formData = {
            'answer' : $('input[name=answer]').val(),
            'submit2' : true
            };

		$.ajax({
			url: "includes/Forgot.php",
			type: "POST",
			data: formData,
			success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");}
		});
		return false;
	};
	</script>
<?php
require('dbconnect.php'); //connects to the PDO database
$username = $_POST['username'] ?? ""; //username = whatever the user entered into the username input
$questions = [
    0 => "Who is your best friend?",
    1 => "What is your mother's maiden name?",
    2 => "What street did you grow up on?",
    3 => "What was your first car?",
    4 => "What is your first pet's name?"
];

if(isset($_POST['submit'])){
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?'); //queries the table for anything with the username = to $username
    $stmt->execute([$username]);
    $query = $stmt->fetchAll();
    if(count($query)==0){die('<script>alert("Username not found!");</script>');} //if the query is empty...returns an error
    if($query[0] != 0){ //if query is not empty it sets the question equal to whatever the username's question was stored in the database
        $_SESSION['question'] = $query; 
        $_SESSION['forgotUser'] = $username; //creating a session variable for the username the user put into the $username field
        echo $questions[$_SESSION['question'][0]['question']];?>
        <input type="text" name="answer" value="" required><br/> 
        <button name="submit" onclick="ajaxSubmit2()">Submit</button>
        <div id="output"></div>
        <?php
    }
}
else{
?>
<div id="output">
Username:<input type="text" name="username" value="<?php echo $username;?>" required><br/>
<button name="submit" onclick="ajaxSubmit();">Submit!</button>
</div>
<?php
}
?>

<?php
if(isset($_POST['submit2'])){ //if sumbit2 is selected which is the submit answer button
    require('dbconnect.php'); //connects to the database
    $answer = $_POST['answer']; //grabs the answer the user typed in
    $username = $_SESSION['forgotUser']; //sets username = to the session stored username
    $answer = str_replace(' ', '_', $answer); //removes spaces and underscores from answer
    if($answer == $_SESSION['question'][0]['answer']){
        $rPass = randomPassword();
        $stmt = $pdo->prepare('UPDATE users SET password = ? WHERE username = ?');
        $stmt->execute([password_hash($rPass, PASSWORD_BCRYPT), $username]);
    echo "New Password: $rPass";
    }
}
?>