<script>
	function ajaxSubmit(){
		var formData = {
            'username' : $('input[name=username]').val(),
            'pass' : $('input[name=pass]').val(),
            'pass1' : $('input[name=pass1]').val(),
            'securityQ' : $('select[name=securityQ]').val(),
            'answer' : $('input[name=answer]').val(),
            'submit' : true
        };

		$.ajax({
			url: "includes/SignUp.php",
			type: "POST",
			data: formData,
			success: function(result){$("#output").html(result);},
			error: function(result){$("#output").html("Error!");}
		});
		return false;
	};
</script>

<?php
require('dbconnect.php');
$username = $_POST['username'] ?? "";

function usernameValid($username, $errors){
    $validUser = '/^[\w]{6,12}$/';
    if (!preg_match($validUser, $username)){
        $errors[] = "Username must be between 6-12 characters in length and can only contain alphanumeric characters(A-Z, a-z, 0-9 or _).";
    }
    
    return $errors;
}

function passwordValid($password, $errors){
    $uppercase = preg_match('/[A-Z]/', $password);
    $lowercase = preg_match('/[a-z]/', $password);
    $number    = preg_match('/[0-9]/', $password);
    $space     = preg_match('/[ ]/', $password);
    $specChar  = preg_match('/[!"#$%&\'()*+,-.\/:;<=>?@[\]^_`{|}~]/', $password);

    if($space){
        $errors[] = "Password can not contain spaces.";
    }
    if(!$uppercase){
        $errors[] = "Password must contain at least one Uppercase letter(A-Z).";
    }
    if(!$lowercase){
        $errors[] = "Password must contain at least one lowercase letter(a-z).";
    }
    if(!$number){
        $errors[] = "Password must contain at least one number(0-9).";
    }
    if(strlen($password) < 8 || strlen($password) > 16){
        $errors[] = "Password length must be between 8-16 characters in length.";
    }
    if(!$specChar){
        $errors[] = "Password must contain at least one special character.";
    }
    //(!\"#$%&'()*+,-./:;<=>?@[\]^_`{|}~)
    return $errors;
}

if(isset($_POST['submit'])){
    $password = $_POST['pass'];
    $verifyPass = $_POST['pass1'];
    $question = $_POST['securityQ'];
    $answer = $_POST['answer'];
    $answer = str_replace(' ', '_', $answer);
    $errors = array();
    $errors = usernameValid($username, $errors);
    $errors = passwordValid($password, $errors);
    if($password != $verifyPass){
        $errors[] = "Passwords do not match.";
    }
    if(count($errors) == 0){
        $stmt = $pdo->prepare('SELECT count(*) as username FROM users WHERE username = ?');
        $stmt->execute([$username]);
        $query = $stmt->fetchAll();
        if($query[0]["username"] == 0){
            //send info to database
            $stmt = $pdo->prepare('INSERT INTO users(username, password, accessLevel, question, answer) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$username, password_hash($password, PASSWORD_BCRYPT), 0, $question, $answer]);
            echo '<script>alert("Account successfully created!");</script>';
            echo '<script>window.location.replace("../index.php");</script>';
        }
        else{
            echo '<script>alert("Username already taken!");</script>';
        }
    }
    else{
        $er = implode("\\n", $errors);
        echo "<script>alert('$er');</script>";
        }
}
else{
    ?>
    Username:<input type="text" name="username" value="<?php echo $username;?>" required><br/>
    Password:<input type="password" name="pass" value="" required><br/>
    Re-type Password:<input type="password" name="pass1" value="" required><br/>
    Security Question:
    <select name="securityQ">
        <option value=0>Who is your best friend?</option>
        <option value=1>What is your mother's maiden name?</option>
        <option value=2>What street did you grow up on?</option>
        <option value=3>What was your first car?</option>
        <option value=4>What is your first pet's name?</option>
    </select><br/>
    Security Question Answer:<input type="text" name="answer" value="" required><br/>
    <button name="submit" onclick="ajaxSubmit();">Submit</button>
    <div id="output"></div>
    <?php
}
?>