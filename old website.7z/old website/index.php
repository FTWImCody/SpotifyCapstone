<!DOCTYPE html>
<html>
	<head>
		<title>Spotify Companion App</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" type="text/css" href="style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script>
		function ajaxNavigation(page){ //Allows you to navigate via Ajax and load the info into #dynamicContent
			var formData = {'page' : page}; //grabs the page value passed in and sends it to control.php

			$.ajax({
				url: "includes/control.php",
				type: "POST",
				data: formData,
				success: function(result){$("#dynamicContent").html(result);},
				error: function(result){$("#dynamicContent").html("Error!");}
			});
			return false;
		};
		</script>
		<?php
		session_start();
		require('includes/dbconnect.php'); //connects to the database
		?>
	</head>
	<body>
		<?php
			require_once('includes/navMenu.php'); //will have navMenu.php on every page
		?>
		<div id="dynamicContent">
		<!--All the content of each page will go into this div-->
		</div>
	</body>
</html>